﻿namespace WebApplication11.ConexionDB
{
    public class Conexion
    {

        private const string keyPath = "ConnectionStrings:DataSource";
        private string? dataSource = string.Empty;

        public Conexion()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true).Build();
            dataSource = builder.GetSection(keyPath).Value;
        }

        public string? getDataSource()
        {
            return dataSource;
        }
    }
}
