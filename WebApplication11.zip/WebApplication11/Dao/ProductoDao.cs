﻿using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using WebApplication11.ConexionDB;
using WebApplication11.Models;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace WebApplication11.Dao
{
    public class ProductoDao
    {

        public string _dataSource;
        Conexion conn = new Conexion();

        public ProductoDao()
        { 
            
        }

        bool outB = false;
        string msg = string.Empty;

        public bool getProductos(out string msg, out List<Producto> _listProductos)
        {
            msg = string.Empty;
            _dataSource = conn.getDataSource();
            _listProductos = new List<Producto>();

            string dbQuery = "select * from [dbo].[Productos]";

            try
            {
                using (SqlConnection conexion = new SqlConnection(_dataSource))
                {                   
                    SqlCommand command = new SqlCommand(dbQuery, conexion);
                    conexion.Open();

                    using (var dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            _listProductos.Add(new Producto()
                            {
                                id = Convert.ToInt32(dr["idProducto"]),
                                codigo = dr["codigo"].ToString(),
                                nombre = dr["nombre"].ToString(),
                                existencias = Convert.ToInt32(dr["existencias"])
                            });
                        }
                    }
                    conexion.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
                msg = ex.ToString();
            }
        }


    }
}
