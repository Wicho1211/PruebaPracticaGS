﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication11.ConexionDB;
using WebApplication11.Dao;
using WebApplication11.Models;

namespace WebApplication11.Controllers
{
    //[ApiController]
    [Route("api/[controller]")]

    public class ProductoController : Controller
    {
        ProductoDao productoDao = new ProductoDao();

        /*
        public ProductoController(ILogger<ProductoController> logger)
        {
            _logger = logger;
        }
        */

        [HttpGet(Name = "GetProductos")]
        // GET: ProductoController
        public IActionResult Index()
        {
            string msnDao = string.Empty;
            List<Producto> _listProductos = new List<Producto>();

            bool outDao = productoDao.getProductos(out msnDao, out _listProductos);

            Console.WriteLine("result " + outDao + " --> msg: " + msnDao);
            return View(_listProductos);
        }

        /*
        // GET: ProductoController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ProductoController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ProductoController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductoController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ProductoController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductoController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ProductoController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        */
    }
}
